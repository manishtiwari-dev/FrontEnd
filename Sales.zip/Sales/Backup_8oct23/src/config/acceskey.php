<?php
return [
     'sales-customer'=>'customer',
     'sales-order'=>'orders',
     'sales-enquiry'=>'sales-enquiry',
     'sales-quotation'=>'quotation',  
     'account-setting' => 'setting',
     'sales-transaction' => 'transaction',
     'sales-custom-quote'=>'custom_quote',
     'sales-invoice'=>'invoice'
];




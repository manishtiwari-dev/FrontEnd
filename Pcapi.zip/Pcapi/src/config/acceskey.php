<?php
return [
    'pc_category' => 'pc_category',
    'pc_product' => 'pc_product', 
];